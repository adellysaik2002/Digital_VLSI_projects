`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/22/2025 05:11:50 PM
// Design Name: 
// Module Name: MUL_ALU2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module MUL_ALU2(
   input clk,
   input reset,
   input is_mispredicted,
   input [31:0] mul_op1,
   input [31:0] mul_op2,
   input [4:0] mul_dest_tag,
   input [3:0] mul_alu_op,
   input mul_ready,
   input mul_broadcast,
   output mul_clear,
   output reg [31:0] mul_result_out,
   output reg [4:0] mul_dest_tag_out,
   output reg mul_valid_out
  );
  
  
   parameter IDLE=0,START=1,INTERMEDIATE=2,DONE=3;
   
    reg [1:0] state,next_state;
     
     
     reg [31:0] op1;
     reg [31:0] op2;
     reg [3:0] alu_op;
     reg [4:0] dest_tag;
     
     always@(posedge clk)
        if(reset || is_mispredicted) state<=IDLE;
        else state<=next_state;
     
     
     assign mul_clear = ((state == IDLE)&& (mul_ready==1))||((state==DONE)&& mul_broadcast && mul_ready);
     
     
     always@(*)
       case(state)
          IDLE:begin
                 next_state<=(mul_ready==1)?START:IDLE;
                 
               end
          START: next_state<=INTERMEDIATE;
          INTERMEDIATE: next_state<=DONE;
          DONE:  next_state=(mul_broadcast==1)?((mul_ready==1)?START:IDLE):DONE;
       endcase
       
       
     always@(posedge clk) begin
         if(reset || is_mispredicted) begin
            op1<=32'd0;
            op2<=32'd0;
            alu_op<=4'd0;
            mul_result_out<=32'd0;
            mul_dest_tag_out<=5'd0;
            mul_valid_out<=1'd0;
         end  
         
         else begin
           if(mul_clear==1) begin
             op1<=mul_op1;
             op2<=mul_op2;
             alu_op<=mul_alu_op;
             dest_tag <= mul_dest_tag;
           end 
           else if(state==DONE && mul_broadcast) begin
             op1<=32'd0;
            op2<=32'd0;
            alu_op<=4'd0;
            mul_result_out<=32'd0;
            mul_dest_tag_out<=5'd0;
            mul_valid_out<=1'd0;
            end
           
           
           if(state==INTERMEDIATE) begin
             case (alu_op)
               4'b1000: mul_result_out = op1 * op2;                         // MUL (lower 32 bits, signed × signed)
               4'b1001: mul_result_out = ($signed(op1) * $signed(op2)) >>> 32; // MULH (upper 32 bits, signed × signed)
               4'b1010: mul_result_out = ($signed(op1) * op2) >>> 32;       // MULHSU (upper 32 bits, signed × unsigned)
               4'b1011: mul_result_out = (op1 * op2) >> 32;                 // MULHU (upper 32 bits, unsigned × unsigned)
    default: mul_result_out = 32'd0;
endcase
            mul_dest_tag_out <= dest_tag;
            mul_valid_out <= 1'd1;
            
           end
          
         end
       end
     
  
  endmodule
