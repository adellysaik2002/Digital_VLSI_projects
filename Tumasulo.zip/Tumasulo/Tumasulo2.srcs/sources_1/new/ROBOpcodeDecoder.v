`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2025 10:21:15 PM
// Design Name: 
// Module Name: ROBOpcodeDecoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module ROBOpcodeDecoder(
    input wire [6:0] opcode,
    output reg [3:0] rob_opcode
);

    always @(*) begin
        case (opcode)
            7'b0110011: rob_opcode = 4'b0001; // R-type INT ALU
            7'b0010011: rob_opcode = 4'b0001; // I-type INT ALU
            7'b0000011: rob_opcode = 4'b0010; // LOAD
            7'b0100011: rob_opcode = 4'b0011; // STORE
            7'b1100011: rob_opcode = 4'b0100; // BRANCH
            7'b1101111: rob_opcode = 4'b0101; // JAL
            7'b1100111: rob_opcode = 4'b0110; // JALR
            7'b0111011: rob_opcode = 4'b1000; // MUL/DIV (M extension)
            default:    rob_opcode = 4'b0000; // UNKNOWN or unsupported
        endcase
        end
endmodule
    
