`timescale 1ns / 1ps

module ReorderBuffer1 #(parameter DEPTH = 16) (
    input wire clk,
    input wire reset,

    // Allocation
    input wire alloc_en,
    input wire [4:0] rd_in,
    
    input wire is_branch_in,
    input wire is_jal_in,
    input wire predict_taken_in,
    input wire [31:0] PC_ROB,
    input wire [31:0] PC_plusIMM_ROB,
    output reg [4:0] alloc_index,
    output wire full,

    // Write-back
    input wire wb_en,
    input wire [4:0] wb_index,
    input wire [31:0] wb_value,
    input wire wb_is_branch,
    input wire wb_taken,
    input wire [31:0] target_pc_in,

    // Commit
    input wire commit_en,
    output reg [4:0] commit_rd,
    output reg [31:0] commit_val,
    output reg commit_valid,
    output reg [4:0] commit_rob_idx,
    output reg [31:0] commit_target_pc,
    
    output reg commit_is_branch,
    output reg commit_is_jal,
    output reg commit_actual_taken,
    output reg is_mispredicted,
    output reg [31:0] commit_branch_pc,

    output reg [4:0] head,
    output reg [4:0] tail
);

    // Fields for each ROB entry
    reg valid            [0:DEPTH-1];
    reg ready            [0:DEPTH-1];
    reg [4:0] rd         [0:DEPTH-1];
    reg [31:0] value     [0:DEPTH-1];
    reg [31:0] PC        [0:DEPTH-1];
    reg is_jal          [0:DEPTH-1];
    reg is_branch        [0:DEPTH-1];
    reg predict_taken  [0:DEPTH-1];
    reg actual_taken     [0:DEPTH-1];

    assign full = ((tail) % (DEPTH-1)+1) == head;

    integer i;
    always @(posedge clk) begin
        if (reset) begin
            head <= 1;
            tail <= 1;
            alloc_index <= 5'd0;
            commit_rd <= 5'd0;
            commit_val <= 32'd0;
            commit_valid <= 1'b0;
            commit_rob_idx <= 5'd0;
            commit_target_pc <= 32'd0;
            commit_actual_taken <=1'b0;
            commit_is_branch <=1'b0;
            commit_is_jal <=1'b0;
            commit_branch_pc <= 32'd0;
            is_mispredicted <= 1'b0;

            for (i = 0; i < DEPTH; i = i + 1) begin
                valid[i] <= 0;
                ready[i] <= 0;
                rd[i] <= 5'd0;
                value[i] <= 32'd0;
                PC[i] <= 32'd0;
                is_jal[i] <= 1'd0;
                is_branch[i] <= 0;
                predict_taken[i] <= 0;
                actual_taken[i] <= 0;
            end
        end else begin
            // Allocation
            if (alloc_en && !full) begin
                valid[tail] <= 1;
                ready[tail] <= is_jal_in;
                rd[tail] <= rd_in;
                is_branch[tail] <= is_branch_in;
                predict_taken[tail] <= predict_taken_in;
                
                value[tail] <= (is_branch_in || is_jal_in)?PC_plusIMM_ROB:32'd0;
                PC[tail] <= PC_ROB;
                is_jal[tail] <= is_jal_in;
                alloc_index <= tail;
                
                 
                tail <= (tail) % (DEPTH-1) + 1;
            end

            // Write-back
            if (wb_en) begin
                value[wb_index] <=(!wb_is_branch)?wb_value:value[wb_index];
                ready[wb_index] <= 1;
                actual_taken[wb_index] <= wb_taken;
            end

            // Commit
            commit_valid <= 0;
            is_mispredicted <= 0;
            commit_rob_idx <= head;
            commit_target_pc <= 32'd0;
            commit_is_branch <= 1'b0;
            commit_is_jal <=1'b0;
            commit_actual_taken <= 1'b0;
            commit_branch_pc <= 32'd0;
            if (commit_en && valid[head] && ready[head] && !is_mispredicted) begin
              commit_rd <= rd[head];
              commit_val <= is_jal[head]?(PC[head]+4):value[head];
              commit_valid <= 1;
              commit_rob_idx <= head;
              commit_target_pc <= value[head];
              commit_is_branch <= is_branch[head];
              commit_is_jal <= is_jal[head];
              commit_actual_taken <= actual_taken[head];
              commit_branch_pc <= PC[head];

    // Mark as committed
              valid[head] <= 0;
              head <= (head) % (DEPTH-1) + 1;

    // Check misprediction after committing
              if ((is_jal[head] && predict_taken[head]==1'b0 )||(is_branch[head] && predict_taken[head] != actual_taken[head])) begin
                is_mispredicted <= 1;
        // Flush from next instruction onwards
                tail <= (head) % (DEPTH-1) + 1; 
                valid[(head) % (DEPTH-1) + 1] <= 0;end
           end

        end
    end

endmodule
