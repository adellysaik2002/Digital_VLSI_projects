`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2025 10:12:53 PM
// Design Name: 
// Module Name: MainDecoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module MainDecoder (
    input wire [31:0] instruction,
    output wire [6:0] opcode,
    output wire [4:0] rd,
    output wire [4:0] rs1,
    output wire [4:0] rs2,
    output wire [2:0] funct3,
    output wire [6:0] funct7,
    output reg [31:0] imm,
    output reg is_branch,
    output reg is_jal,
    output reg is_jalr,
    output reg is_immediate
);

    assign opcode = instruction[6:0];
    assign rd = instruction[11:7];
    assign funct3 = instruction[14:12];
    assign rs1 = instruction[19:15];
    assign rs2 = instruction[24:20];
    assign funct7 = instruction[31:25];

    always @(*) begin
        is_branch = 0;
        is_jal = 0;
        is_jalr =0;
        is_immediate = 0;
        imm = 32'b0;

        case (opcode)
            7'b0010011: begin // I-type ALU instructions
                imm = {{20{instruction[31]}}, instruction[31:20]};
                is_immediate = 1;
            end
            7'b0000011: begin // I-type Load
                imm = {{20{instruction[31]}}, instruction[31:20]};
                is_immediate = 1;
            end
            7'b0100011: begin // S-type Store
                imm = {{20{instruction[31]}}, instruction[31:25], instruction[11:7]};
                is_immediate = 1; // immediate is used for address offset
            end
            7'b1100011: begin // B-type Branch
                imm = {{19{instruction[31]}}, instruction[31], instruction[7], instruction[30:25], instruction[11:8], 1'b0};
                is_branch = 1;
                is_immediate = 0;
            end
            7'b1101111: begin // J-type JAL
                imm = {{11{instruction[31]}}, instruction[31], instruction[19:12], instruction[20], instruction[30:21], 1'b0};
                is_jal = 1;
                is_immediate = 0; // PC-relative offset
            end
            7'b1100111: begin // I-type JALR
                imm = {{20{instruction[31]}}, instruction[31:20]};
                is_jalr = 1;
                is_immediate = 1;
            end
            default: begin
                imm = 32'd0;
                is_immediate = 0;
            end
        endcase
    end

endmodule
