`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2025 02:39:24 PM
// Design Name: 
// Module Name: DIV_ALU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module DIV_ALU (
    input        clk,
    input        reset,
    input  [3:0] opcode,
    input  [31:0] op1,
    input  [31:0] op2,
    input        start,
    output reg [31:0] result,
    output reg       done
);
    reg [3:0] cycle;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            cycle <= 0;
            done  <= 0;
        end else begin
            if (start && cycle == 0) begin
                cycle <= 1;
                done  <= 0;
            end else if (cycle != 0 && cycle < 10) begin
                cycle <= cycle + 1;
            end else if (cycle == 10) begin
                cycle <= 0;
                done  <= 1;
                case (opcode)
                    4'b1001: result <= (op2 != 0) ? op1 / op2 : 0; // DIV
                    4'b1010: result <= (op2 != 0) ? op1 % op2 : 0; // REM
                    default: result <= 0;
                endcase
            end else begin
                done <= 0;
            end
        end
    end
endmodule

