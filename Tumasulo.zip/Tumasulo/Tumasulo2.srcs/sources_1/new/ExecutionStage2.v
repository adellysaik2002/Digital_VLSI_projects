`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/22/2025 09:49:27 AM
// Design Name: 
// Module Name: ExecutionStage2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns/1ps
// ExecutionStage.v
module ExecutionStage2 (
    input wire clk,
    input wire reset,
    input wire is_mispredicted,

    // Inputs from dispatch stage
    input wire [223:0] src1_val_ex_flat, // 7 x 32
    input wire [223:0] src2_val_ex_flat, // 7 x 32
    input wire [6:0] ready_ex_flat,      // 7 x 1
    input wire [27:0] alu_op_ex_flat,       // 7 x 4
    input wire [34:0] dest_tag_ex_flat,  
       // 7 x 5

    // Outputs
    output reg [31:0] result,
    output reg [4:0] result_tag,
    output reg valid_out,
    output reg result_taken,
    output reg result_is_branch,
    output reg[6:0] clear_entry
);

    // Decode flattened inputs into arrays
    wire [31:0] src1_val_ex [0:6];
    wire [31:0] src2_val_ex [0:6];
    wire [3:0] alu_op_ex [0:6];
    wire [4:0] dest_tag_ex [0:6];
    wire ready_ex [0:6];
    
   
    genvar i;
    generate
        for (i = 0; i < 7; i = i + 1) begin : decode
            assign src1_val_ex[i] = src1_val_ex_flat[i*32 +: 32];
            assign src2_val_ex[i] = src2_val_ex_flat[i*32 +: 32];
            assign alu_op_ex[i]  = alu_op_ex_flat[i*4 +: 4];
            assign dest_tag_ex[i] = dest_tag_ex_flat[i*5 +: 5];
            assign ready_ex[i] = ready_ex_flat[i];
        end
    endgenerate
    
    
    
    //signals for INT_ALU
    wire [31:0] int_op1;
    wire [31:0] int_op2;
    wire [4:0] int_dest_tag;
    wire [3:0] int_alu_op;
    wire int_ready;
    wire [1:0] int_clear_idx;
    wire int_clear;
    wire [31:0] int_result_out;
    wire int_valid_out;
    wire [4:0] int_dest_tag_out;
    reg int_broadcast;
    
    
    //signals for MUL_ALU
    wire [31:0] mul_op1;
    wire [31:0] mul_op2;
    wire [4:0] mul_dest_tag;
    wire [3:0] mul_alu_op;
    wire mul_ready;
    wire mul_clear;
    wire [31:0] mul_result_out;
    wire mul_valid_out;
    wire [4:0] mul_dest_tag_out;
    reg mul_broadcast;
    
     wire [31:0] branch_op1;
    wire [31:0] branch_op2;
    wire [4:0] branch_dest_tag;
    wire [3:0] branch_alu_op;
    wire branch_ready;
    wire branch_clear;
    wire [31:0] branch_result_out;
    wire branch_taken_out;
    wire branch_valid_out;
    
    wire [4:0] branch_dest_tag_out;
    reg branch_broadcast;
    
    
    
    
    
    
    always@(*) begin
       mul_broadcast =1'b0;
       int_broadcast =1'b0;
       branch_broadcast =1'b0;
       result_taken =1'b0;
       result_is_branch =1'b0;
      if(mul_valid_out) begin
         result = mul_result_out;
         result_tag = mul_dest_tag_out;
         valid_out = 1'b1;
         mul_broadcast =1'b1;
      end else if(int_valid_out) begin
         result = int_result_out;
         result_tag = int_dest_tag_out;
         valid_out = 1'b1;
         int_broadcast =1'b1; 
      end else if(branch_valid_out) begin
         result = branch_result_out;
         result_taken =branch_taken_out;
         result_tag = branch_dest_tag_out;
         valid_out = 1'b1;
         branch_broadcast =1'b1;
         result_is_branch =1'b1; end
      else begin 
         result = 32'd0;
         result_tag = 5'd0;
         valid_out = 1'b0; end
         
         
    
    
   end
       
    
    
    assign int_op1=(ready_ex[0])?src1_val_ex[0]:(ready_ex[1])?src1_val_ex[1]:(ready_ex[2])?src1_val_ex[2]:32'd0;
    assign int_op2=(ready_ex[0])?src2_val_ex[0]:(ready_ex[1])?src2_val_ex[1]:(ready_ex[2])?src2_val_ex[2]:32'd0;
    assign int_alu_op=(ready_ex[0])?alu_op_ex[0]:(ready_ex[1])?alu_op_ex[1]:(ready_ex[2])?alu_op_ex[2]:32'd0;
    assign int_dest_tag=(ready_ex[0])?dest_tag_ex[0]:(ready_ex[1])?dest_tag_ex[1]:(ready_ex[2])?dest_tag_ex[2]:32'd0;
    assign int_ready=ready_ex[0]|ready_ex[1]|ready_ex[2];
    assign int_clear_idx=(ready_ex[0])?2'd0:(ready_ex[1])?2'd1:2'd2;
    
   assign mul_op1=src1_val_ex[5];
   assign mul_op2=src2_val_ex[5];
   assign mul_dest_tag=dest_tag_ex[5];
   assign mul_alu_op=alu_op_ex[5];
   assign mul_ready=ready_ex[5];   
    
    
   assign branch_op1=src1_val_ex[3];
   assign branch_op2=src2_val_ex[3];
   assign branch_dest_tag=dest_tag_ex[3];
   assign branch_alu_op=alu_op_ex[3];
   assign branch_ready=ready_ex[3];
   
   
    always @(*) begin
       clear_entry = 7'd0;
       if(int_clear)
         clear_entry[int_clear_idx]=1'b1;
       if(mul_clear)
         clear_entry[5]=1'b1;
       if(branch_clear)
         clear_entry[3]=1'b1;    
     end
    
    INT_ALU2 alu_int(
       .clk(clk),
       .reset(reset),
       .is_mispredicted(is_mispredicted),
       .int_op1(int_op1),
       .int_op2(int_op2),
       .int_dest_tag(int_dest_tag),
       .int_alu_op(int_alu_op),
       .int_ready(int_ready),
       .int_clear(int_clear),
       .int_broadcast(int_broadcast),
       .int_result_out(int_result_out),
       .int_dest_tag_out(int_dest_tag_out),
       .int_valid_out(int_valid_out)
       );
       
       
     MUL_ALU2 alu_mul(
        .clk(clk),
        .reset(reset),
        .is_mispredicted(is_mispredicted),
        .mul_op1(mul_op1),
        .mul_op2(mul_op2),
        .mul_dest_tag(mul_dest_tag),
        .mul_alu_op(mul_alu_op),
        .mul_ready(mul_ready),
        .mul_clear(mul_clear),
        .mul_broadcast(mul_broadcast),
        .mul_result_out(mul_result_out),
        .mul_dest_tag_out(mul_dest_tag_out),
        .mul_valid_out(mul_valid_out)
        );
        
        
     BRANCH_ALU2 alu_branch(
        .clk(clk),
        .reset(reset),
        .is_mispredicted(is_mispredicted),
        .branch_op1(branch_op1),
        .branch_op2(branch_op2),
        .branch_dest_tag(branch_dest_tag),
        .branch_alu_op(branch_alu_op),
        .branch_ready(branch_ready),
        .branch_clear(branch_clear),
        .branch_broadcast(branch_broadcast),
        .branch_result_out(branch_result_out),
        .branch_taken_out(branch_taken_out),
        .branch_dest_tag_out(branch_dest_tag_out),
        .branch_valid_out(branch_valid_out)
        );
       
    
    
    
  
endmodule
