`timescale 1ns / 1ps

module GSharePredictor #(parameter HISTORY_BITS = 10, TABLE_SIZE = 1024) (
    input wire clk,
    input wire reset,

    // Query path
    input wire [31:0] pc_query,
    input wire [HISTORY_BITS-1:0] global_history,
    output wire prediction,
    output reg [HISTORY_BITS-1:0] global_history_out,

    // Update path
    input wire update_en,
    input wire [31:0] pc_update,
    input wire actual_taken
);

    reg [1:0] table1 [0:TABLE_SIZE-1];

    wire [9:0] index_query = pc_query[11:2] ^ global_history;
    wire [9:0] index_update = pc_update[11:2] ^ global_history;
    wire [1:0] pred_bits = table1[index_query];
    assign prediction = pred_bits[1];

    integer i;
    always @(posedge clk) begin
        if (reset) begin
            global_history_out <= 0;
            for (i = 0; i < TABLE_SIZE; i = i + 1)
                table1[i] <= 2'b01;

        end else if (update_en) begin
            

            if (actual_taken && table1[index_update] != 2'b11)
                table1[index_update] <= table1[index_update] + 1;
            else if (!actual_taken && table1[index_update] != 2'b00)
                table1[index_update] <= table1[index_update] - 1;

            global_history_out <= {global_history[HISTORY_BITS-2:0], actual_taken};
        end
    end

endmodule
