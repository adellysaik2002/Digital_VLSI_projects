`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2025 10:34:52 PM
// Design Name: 
// Module Name: Rat_controller
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Rat_controller (
    input clk,
    input reset,

    // Decode inputs
    input [4:0] rs1,
    input [4:0] rs2,
    input [4:0] rd,

    // ROB tag for new instruction
    input alloc_en,
    input [4:0] alloc_index,
    input RS_full_stall,

    // Commit interface
    input commit_en,
    input [4:0] commit_rd,
    input [4:0] commit_rob_idx,
    input is_mispredicted,

    // Outputs to issue stage
    output reg [4:0] src1_rat_tag,
    output reg [4:0] src2_rat_tag
    );

    reg [4:0] rat_table [0:31];  // Rename table: maps reg to ROB tag
    
    integer i;
    always @(posedge clk) begin
        if (reset || is_mispredicted) begin
            for (i = 0; i < 32; i = i + 1)
                rat_table[i] <= 0;
        end else begin
            // Commit update: only clear if no rename conflict
//            if (commit_en && rat_table[commit_rd] == commit_rob_idx && rd != commit_rd)
//                rat_table[commit_rd] <= 0;
            
            if (commit_en && rat_table[commit_rd] == commit_rob_idx)
                rat_table[commit_rd] <= 0;

            // Rename destination register
            if (alloc_en)
                if(rd!=0) begin rat_table[rd] <= alloc_index;end
                
        end
    end

    // Read source register tags and validity
    always @(*) begin
        src1_rat_tag   = rat_table[rs1];
        src2_rat_tag   = rat_table[rs2];
    end

endmodule