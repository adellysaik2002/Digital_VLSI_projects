`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/25/2025 05:57:47 PM
// Design Name: 
// Module Name: PSharePredictor
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module PSharePredictor #(parameter HISTORY_BITS = 10, TABLE_SIZE = 1024) (
    input wire clk,
    input wire reset,

    // For prediction
    input wire [31:0] pc_query,
    output wire prediction,
    output reg [HISTORY_BITS-1:0] local_history_out,

    // For update
    input wire update_en,
    input wire [31:0] pc_update,
    input wire actual_taken
);
    reg [1:0] table1 [0:TABLE_SIZE-1];
    reg [HISTORY_BITS-1:0] local_history_table [0:TABLE_SIZE-1];

    wire [9:0] index_query = local_history_table[pc_query[11:2]]^pc_query[11:2];
    wire [9:0] index_update = local_history_table[pc_update[11:2]]^pc_update[11:2];
    wire [1:0] pred_bits = table1[index_query];
    assign prediction = pred_bits[1];
    
    
    integer i;
    always @(posedge clk) begin
        if (reset) begin
            for ( i = 0; i < TABLE_SIZE; i=i+1) begin
                table1[i] <= 2'b01;
                local_history_table[i] <= 0;
            end
        end else if (update_en) begin
            if (actual_taken && table1[index_update] != 2'b11)
                table1[index_update] <= table1[index_update] + 1;
            else if (!actual_taken && table1[index_update] != 2'b00)
                table1[index_update] <= table1[index_update] - 1;

            local_history_table[pc_update[11:2]] <= {local_history_table[pc_update[11:2]][HISTORY_BITS-2:0], actual_taken};
        end

        local_history_out <= local_history_table[pc_query[11:2]];
    end
endmodule