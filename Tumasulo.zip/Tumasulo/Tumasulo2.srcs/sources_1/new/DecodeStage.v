`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2025 09:57:28 PM
// Design Name: 
// Module Name: DecodeStage
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

// DecodeStage.v
module DecodeStage (
    input wire clk,
    input wire reset,
    input wire [31:0] Instruction_D,
    input wire [31:0] PC_D,
    input wire [31:0] PC_pred_D,
    input wire predict_taken_D,
    
    input wire RS_full_stall,
    
    input wire [4:0] broadcast_tag,
    input wire [31:0] broadcast_value,
    input wire broadcast_en,
    input wire broadcast_taken,
    input wire broadcast_is_branch,
    
    output wire is_mispredicted,
    output wire [31:0] correct_address,
    output wire [31:0] commit_branch_pc,
    output wire commit_actual_taken,
    output wire commit_is_branch,
    output wire commit_is_jal,
    
    output wire [31:0]commit_broadcast_value,
    output wire [4:0] commit_broadcast_tag,
    output wire commit_broadcast_valid,
    
    output reg [6:0] opcode_Dis,
    output reg [2:0] funct3_Dis,
    output reg [6:0] funct7_Dis,
    output reg [4:0] dest_tag_Dis,
    output reg [4:0] src1_tag_Dis,
    output reg [4:0] src2_tag_Dis,
    output reg [31:0] src1_value_Dis,
    output reg [31:0] src2_value_Dis,
    output reg src1_valid_Dis,
    output reg src2_valid_Dis
);

     //register(before next stage) input signals;
     wire [4:0] src1_tag;
     wire [4:0] src2_tag;
     wire [31:0] src1_value;
     wire [31:0] src2_value;
     wire src1_valid;
     wire src2_valid;
     
     
   

    //main decoder signals
    wire [6:0] opcode;
    wire [2:0] funct3;
    wire [6:0] funct7;
    wire [4:0] rs1;
    wire [4:0] rs2;
    wire [4:0] rd;
    wire[31:0] imm;
    wire is_branch;
    wire is_jal;
    wire is_jalr;
    wire is_return;
    wire is_immediate;
    
    
      
     
      //wire is_mispredicted;
      
      wire [31:0] PC_plusIMM = PC_D + imm;



    // ROB commit interface
    wire commit_en;
    assign commit_en = !is_mispredicted;
    wire [4:0] commit_rd;
    wire [31:0] commit_val;
    wire commit_valid;
    wire [4:0]commit_rob_idx;
    wire [31:0] commit_target_pc;
    
   assign commit_broadcast_value = commit_val;
   assign commit_broadcast_tag = commit_rob_idx;
   assign commit_broadcast_valid = commit_valid;
   // wire is_mispredicted;
    
    wire [4:0] head;
    wire [4:0] tail;
    wire full;
    wire [4:0] rob_alloc_index;
    // Allocation logic
    wire alloc_en;
    
    
    reg RS_full_stall_delayed;
    
    always@(posedge clk)
      RS_full_stall_delayed <= RS_full_stall;
    assign alloc_en = (Instruction_D != 32'd0) && (Instruction_D != 32'h00000013) && (!RS_full_stall)&&(!is_mispredicted);

   
    
    //RAT Outputs
    wire [4:0] src1_rat_tag;
    wire [4:0] src2_rat_tag;

   wire [4:0] rd_in=(is_branch)?5'd0:rd;
    // Instantiate Main Decoder
    MainDecoder main_decoder (
    .instruction(Instruction_D),
    .opcode(opcode),
    .rd(rd),
    .rs1(rs1),
    .rs2(rs2),
    .funct3(funct3),
    .funct7(funct7),
    .imm(imm),
    .is_branch(is_branch),
    .is_jal(is_jal),
    .is_jalr(is_jalr),
    .is_immediate(is_immediate)  // New output signal connected
);


 
    assign correct_address = commit_target_pc;
   
    ReorderBuffer1 rob (
        .clk(clk),
        .reset(reset),
        .alloc_en(alloc_en),
        .rd_in(rd_in),
        .alloc_index(rob_alloc_index),
        .full(full),
        .is_branch_in(is_branch),
        .is_jal_in(is_jal),
        .predict_taken_in(predict_taken_D),
        .PC_ROB(PC_D),
        .PC_plusIMM_ROB(PC_plusIMM),
        .is_mispredicted(is_mispredicted),
        .wb_en(broadcast_en),
        .wb_index(broadcast_tag),
        .wb_value(broadcast_value),
        .wb_is_branch(broadcast_is_branch),
        .wb_taken(broadcast_taken),
        .commit_en(commit_en),
        .commit_rd(commit_rd),
        .commit_val(commit_val),
        .commit_valid(commit_valid),
        .commit_rob_idx(commit_rob_idx),
        .commit_is_branch(commit_is_branch),
        .commit_is_jal(commit_is_jal),
        .commit_actual_taken(commit_actual_taken),
        .commit_target_pc(commit_target_pc),
        .commit_branch_pc(commit_branch_pc),
        .head(head),
        .tail(tail)
    );

    // Instantiate RAT Controller
    Rat_controller Rat (
        .clk(clk),
        .reset(reset),
        .rs1(rs1),
        .rs2(rs2),
        .rd(rd),
        .alloc_en(alloc_en),
        .alloc_index(tail),
        .RS_full_stall(RS_full_stall),
        .commit_en(commit_valid),
        .commit_rd(commit_rd),
        .commit_rob_idx(commit_rob_idx),
        .is_mispredicted(is_mispredicted),
        .src1_rat_tag(src1_rat_tag),
        .src2_rat_tag(src2_rat_tag)
       
        
    );

    // Instantiate Register File
    wire [31:0] rs1_data;
    wire [31:0] rs2_data;
    RegisterFile rf (
        .clk(clk),
        .reset(reset),
        .rs1(rs1),
        .rs2(rs2),
        .rs1_data(rs1_data),
        .rs2_data(rs2_data),
        .commit_en(commit_valid),
        .commit_rd(commit_rd),
        .commit_val(commit_val)
    );
    
    assign src1_valid=(src1_rat_tag==0)?1:0;
    assign src2_valid=(is_immediate==1)?1:(src2_rat_tag==0)?1:0;
    assign src1_value=(src1_rat_tag==0)?rs1_data:32'd0;
    assign src2_value=(is_immediate==1)?imm:(src2_rat_tag==0)?rs2_data:32'd0;
    assign src1_tag=(src1_valid==1)?5'd0:src1_rat_tag;
    assign src2_tag=(src2_valid==1)?5'd0:src2_rat_tag;
    
    always@(posedge clk)
       if(reset==1 || is_mispredicted)
        begin
          opcode_Dis<=7'd0;
          funct7_Dis<=7'd0;
          funct3_Dis<=3'd0;
          dest_tag_Dis<=5'd0;
          src1_tag_Dis<=5'd0;
          src2_tag_Dis<=5'd0;
          src1_value_Dis<=32'd0;
          src2_value_Dis<=32'd0;
          src1_valid_Dis<=1'd0;
          src2_valid_Dis<=1'd0;
         end
        else if(RS_full_stall)  
          begin
          opcode_Dis<=opcode_Dis;
          funct7_Dis<=funct7_Dis;
          funct3_Dis<=funct3_Dis;
          dest_tag_Dis<=dest_tag_Dis;
          src1_tag_Dis<=src1_tag_Dis;
          src2_tag_Dis<=src2_tag_Dis;
          src1_value_Dis<=src1_value_Dis;
          src2_value_Dis<=src2_value_Dis;
          src1_valid_Dis<=src1_valid_Dis;
          src2_valid_Dis<=src2_valid_Dis;
         end
         else begin
          if((Instruction_D != 32'd0) && (Instruction_D != 32'h00000013) &&(!is_mispredicted)) begin
          opcode_Dis<=opcode;
          funct7_Dis<=funct7;
          funct3_Dis<=funct3;
          dest_tag_Dis<=tail;
          src1_tag_Dis<=src1_tag;
          src2_tag_Dis<=src2_tag;
          src1_value_Dis<=src1_value;
          src2_value_Dis<=src2_value;
          src1_valid_Dis<=src1_valid;
          src2_valid_Dis<=src2_valid; 
          end else begin
          opcode_Dis<=7'd0;
          funct7_Dis<=7'd0;
          funct3_Dis<=3'd0;
          dest_tag_Dis<=5'd0;
          src1_tag_Dis<=5'd0;
          src2_tag_Dis<=5'd0;
          src1_value_Dis<=32'd0;
          src2_value_Dis<=32'd0;
          src1_valid_Dis<=1'd0;
          src2_valid_Dis<=1'd0; end
          
         end
          
          
       
endmodule
