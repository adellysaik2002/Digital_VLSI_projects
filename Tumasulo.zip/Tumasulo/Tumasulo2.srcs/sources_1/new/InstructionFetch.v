`timescale 1ns / 1ps

module InstructionFetch(
    input  wire        clk,
    input  wire        reset,
    input  wire        flush,
    input  wire        RS_full_stall,
    input  wire [31:0] target_address,     // Flush target (from EX)

    // === Branch Predictor Update Interface ===
    input  wire        predictor_update_en,
    input  wire [31:0] predictor_pc_update,
    input  wire        predictor_actual_taken,

    // === BTB Update Interface ===
    input  wire        btb_update_en,
    input  wire [31:0] btb_pc_update,
    input  wire [31:0] btb_target_update,
    input  wire        btb_is_return_update,
    input  wire        btb_is_jal_update,

    // === RAS Update Interface ===
    input  wire        ras_push_en,
    input  wire [31:0] ras_push_addr,
    input  wire        ras_pop_en,

    output reg  [31:0] PC_D,
    output reg  [31:0] Instruction_D,
    output reg  [31:0] PC_pred_D,
    output reg predict_taken_D
);

    reg [31:0] PC;
    wire [31:0] Instruction;

    wire [31:0] predicted_target;
    wire        predict_taken;
    wire        btb_hit;
    wire        is_return;
    wire        is_jal;
    wire [31:0] ras_top;

    // === Instruction Memory ===
    Instruction_Memory Instruction_Memory (
        .rst(reset),
        .A(PC),
        .RD(Instruction)
    );

    // === Instantiate Tournament Predictor ===
    TournamentPredictor predictor (
        .clk(clk),
        .reset(reset),
        .pc_query(PC),
        .predict_taken(predict_taken),
        .update_en(predictor_update_en),
        .pc_update(predictor_pc_update),
        .actual_taken(predictor_actual_taken)
    );

    // === Instantiate BTB ===
    BTB btb (
        .clk(clk),
        .reset(reset),
        .pc_query(PC),
        .hit(btb_hit),
        .predicted_target(predicted_target),
        .is_return(is_return),
        .is_jal(is_jal),
        .update_en(btb_update_en),
        .pc_update(btb_pc_update),
        .target_update(btb_target_update),
        .return_update(btb_is_return_update),
        .jal_update(btb_is_jal_update)
    );

    // === Instantiate RAS ===
    RAS ras (
        .clk(clk),
        .reset(reset),
        .push_en(ras_push_en),
        .push_addr(ras_push_addr),
        .pop_en(ras_pop_en),
        .ras_top(ras_top)
    );

    // === PC Update Logic ===
    always @(posedge clk) begin
        if (reset) begin
            PC <= 32'd0;
            PC_D <= 32'd0;
            Instruction_D <= 32'd0;
            PC_pred_D <= 32'd0;
            predict_taken_D <= 1'd0;
        end else begin
            if (RS_full_stall) begin
                PC <= PC; // Hold
            end else if (flush) begin
                PC <= target_address;
            end else if (btb_hit && (predict_taken||is_jal) ) begin
                PC <= predicted_target;
            end else begin
                PC <= PC + 4;
            end

            if (RS_full_stall) begin
                PC_D <= PC_D;
                Instruction_D <= Instruction_D;
                PC_pred_D <= PC_pred_D;
                predict_taken_D <= predict_taken_D;
            end else begin
                PC_D <= PC;
                Instruction_D <= Instruction;
                PC_pred_D <= (btb_hit && (predict_taken||is_jal))?(predicted_target):PC+4;
                predict_taken_D <= (predict_taken||is_jal);
            end
        end
    end

endmodule
