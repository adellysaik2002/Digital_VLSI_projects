`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2025 05:10:06 PM
// Design Name: 
// Module Name: Instruction_Memory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module Instruction_Memory(
    input         rst,
    input  [31:0] A,
    output [31:0] RD
);

    // Instruction memory with 1024 words (4KB space)
    reg [31:0] mem [0:1023];

    // Instruction fetch: aligned to 4-byte boundaries (A[31:2])
    assign RD = (!rst) ? mem[A[31:2]] : 32'd0;

    // Load instructions from external memory file (hex format)
    initial begin
    $readmemh("memfile.mem", mem);  // Make sure this file exists in your Vivado simulation directory
    end

    /*
    // Optional: manual memory initialization for debugging or development
    initial begin
        // mem[0] = 32'hFFC4A303;  // Example: LW x6, -4(x9)
        // mem[1] = 32'h00832383;  // Example: LW x7, 8(x6)
        // mem[0] = 32'h0064A423;  // SW x6, 8(x9)
        // mem[1] = 32'h00B62423;  // SW x11, 8(x12)
        mem[0] = 32'h0062E233;    // Example R-type instruction: AND x4, x5, x6
    end
    */

endmodule

