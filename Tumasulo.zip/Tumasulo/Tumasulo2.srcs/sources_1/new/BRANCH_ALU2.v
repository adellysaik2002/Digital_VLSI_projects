`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/28/2025 11:45:48 AM
// Design Name: 
// Module Name: BRANCH_ALU2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/22/2025 10:04:33 AM
// Design Name: 
// Module Name: INT_ALU2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module BRANCH_ALU2(
   input clk,
   input reset,
   input is_mispredicted,
   input [31:0] branch_op1,
   input [31:0] branch_op2,
   input [4:0] branch_dest_tag,
   input [3:0] branch_alu_op,
   input branch_ready,
   input branch_broadcast,
   output branch_clear,
   output reg [31:0] branch_result_out,
   output reg branch_taken_out,
   output reg [4:0] branch_dest_tag_out,
   output reg branch_valid_out
   
     );
     
     
     parameter IDLE=0,START=1,DONE=2;
     
     reg [1:0] state,next_state;
     
     
     reg [31:0] op1;
     reg [31:0] op2;
     reg [3:0] alu_op;
     reg [4:0] dest_tag;
     
     
     
     always@(posedge clk)
        if(reset || is_mispredicted) state<=IDLE;
        else state<=next_state;
     
     assign branch_clear = ((state == IDLE)&& (branch_ready==1))||((state==DONE)&& branch_broadcast && branch_ready);
     always@(*)
       case(state)
          IDLE:begin
                 next_state<=(branch_ready==1)?START:IDLE;
                 
               end
          START: next_state<=DONE;
          DONE:  next_state=(branch_broadcast==1)?((branch_ready==1)?START:IDLE):DONE;
       endcase
       
       
     always@(posedge clk) begin
         if(reset || is_mispredicted) begin
            op1<=32'd0;
            op2<=32'd0;
            alu_op<=4'd0;
            branch_result_out<=32'd0;
            branch_dest_tag_out<=5'd0;
            branch_taken_out <=1'd0;
            branch_valid_out<=1'd0;
         end  
         
         else begin
           if(branch_clear==1) begin
             op1<=branch_op1;
             op2<=branch_op2;
             alu_op<=branch_alu_op;
             dest_tag <= branch_dest_tag;
           end 
           else if(state==DONE && branch_broadcast)begin
            op1<=32'd0;
            op2<=32'd0;
            alu_op<=4'd0;
            branch_result_out<=32'd0;
            branch_dest_tag_out<=5'd0;
            branch_valid_out<=1'd0;
            branch_taken_out<=1'd0;
         end  
           
           if (state == START) begin
    case (alu_op)
        4'b1000: branch_taken_out = (op1 == op2);             // BEQ
        4'b1001: branch_taken_out = (op1 != op2);             // BNE
        4'b1010: branch_taken_out = ($signed(op1) < $signed(op2)); // BLT
        4'b1011: branch_taken_out = ($signed(op1) >= $signed(op2)); // BGE
        4'b1100: branch_taken_out = (op1 < op2);              // BLTU
        4'b1101: branch_taken_out = (op1 >= op2);             // BGEU
        4'b1111: branch_taken_out = 1'b1;                     // JALR (unconditional)
        default: branch_taken_out = 1'b0;                     // Default: not taken
    endcase
    branch_valid_out     <= 1'd1;
    branch_dest_tag_out  <= dest_tag; // still send dest tag if needed
end

         end
       end
             
         
     
     
endmodule
