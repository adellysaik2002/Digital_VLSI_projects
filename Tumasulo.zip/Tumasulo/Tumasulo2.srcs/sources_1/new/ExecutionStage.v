`timescale 1ns/1ps
// ExecutionStage.v
module ExecutionStage (
    input wire clk,
    input wire reset,

    // Inputs from dispatch stage
    input wire [223:0] src1_val_ex_flat, // 7 x 32
    input wire [223:0] src2_val_ex_flat, // 7 x 32
    input wire [6:0] ready_ex_flat,      // 7 x 1
    input wire [27:0] alu_op_ex_flat,       // 7 x 4
    input wire [34:0] dest_tag_ex_flat,  
       // 7 x 5

    // Outputs
    output reg [31:0] result,
    output reg [4:0] result_tag,
    output reg valid_out,
    
    output reg[6:0] clear_entry
);

    // Decode flattened inputs into arrays
    wire [31:0] src1_val_ex [0:6];
    wire [31:0] src2_val_ex [0:6];
    wire [3:0] alu_op_ex [0:6];
    wire [4:0] dest_tag_ex [0:6];
    wire ready_ex [0:6];
    
   
    genvar i;
    generate
        for (i = 0; i < 7; i = i + 1) begin : decode
            assign src1_val_ex[i] = src1_val_ex_flat[i*32 +: 32];
            assign src2_val_ex[i] = src2_val_ex_flat[i*32 +: 32];
            assign alu_op_ex[i]  = alu_op_ex_flat[i*4 +: 4];
            assign dest_tag_ex[i] = dest_tag_ex_flat[i*5 +: 5];
            assign ready_ex[i] = ready_ex_flat[i];
        end
    endgenerate
    
    
    //registers to store operands
    reg [31:0]int_op1;
    reg [31:0]int_op2;
    reg [4:0] int_dest_tag;
    reg [3:0] int_alu_op;
    reg int_start;
    
    reg [31:0]branch_op1;
    reg [31:0]branch_op2;
    reg [4:0] branch_dest_tag;
    reg [3:0] branch_alu_op;
    reg branch_start;
    
    reg [31:0]mul_op1;
    reg [31:0]mul_op2;
    reg [4:0] mul_dest_tag;
    reg [3:0] mul_alu_op;
    reg mul_start;
    
    reg [31:0]div_op1;
    reg [31:0]div_op2;
    reg [4:0] div_dest_tag;
    reg [3:0] div_alu_op;
    reg div_start;
    
    reg [31:0]ls_op1;
    reg [31:0]ls_op2;
    reg [4:0] ls_dest_tag;
    reg [3:0] ls_alu_op;
    reg ls_start;
    // Wires for ALU outputs and ready signals
    wire [31:0] int_result;
    wire int_done;
    wire [31:0] branch_result;
    wire branch_done;
    wire [31:0] loadstore_result;
    wire loadstore_done;
    wire [31:0] mul_result;
    wire mul_done;
    wire [31:0] div_result;
    wire div_done;
    
    
    wire int_valid;
    wire mul_valid;
    wire div_valid;
    wire branch_valid;
    wire loadstore_valid;
    
    reg int_validate;
    reg mul_validate;
    reg div_validate;
    reg branch_validate;
    reg loadstore_validate;
    
always @(*)begin
           clear_entry<=7'b0;
if (ready_ex[0] && int_done) begin
            clear_entry[0]<=1'b1;
        end else if (ready_ex[1] && int_done) begin
            clear_entry[1]<=1'b1;
        end else if (ready_ex[2] && int_done) begin
            clear_entry[2]<=1'b1;
        end 
        if (ready_ex[3] && branch_done) begin
            clear_entry[3]<=1'b1;
        end 
        if (ready_ex[4]) begin
            clear_entry[4]<=1'b1;
        end
        if (ready_ex[5] && mul_done) begin
            clear_entry[5]<=1'b1;
        end
        if (ready_ex[6] && div_done) begin
            clear_entry[6]<=1'b1;
        end
        
        end
  

   
always @(posedge clk) begin
    if (reset) begin
        // Integer unit
       // flag<=1'b0;
        int_op1       <= 32'b0;
        int_op2       <= 32'b0;
        int_dest_tag  <= 5'b0;
        int_alu_op    <= 4'b0;
        int_start     <= 1'b0;

        // Branch unit
        branch_op1       <= 32'b0;
        branch_op2       <= 32'b0;
        branch_dest_tag  <= 5'b0;
        branch_alu_op    <= 4'b0;
        branch_start     <= 1'b0;

        // Multiply unit
        mul_op1       <= 32'b0;
        mul_op2       <= 32'b0;
        mul_dest_tag  <= 5'b0;
        mul_alu_op    <= 4'b0;
        mul_start     <= 1'b0;

        // Divide unit
        div_op1       <= 32'b0;
        div_op2       <= 32'b0;
        div_dest_tag  <= 5'b0;
        div_alu_op    <= 4'b0;
        div_start     <= 1'b0;

        // Load/Store unit
        ls_op1       <= 32'b0;
        ls_op2       <= 32'b0;
        ls_dest_tag  <= 5'b0;
        ls_alu_op    <= 4'b0;
        ls_start     <= 1'b0;
        
        //clear_entry<=7'b0;
    end
    
    
        
        
        else begin
        clear_entry<=6'b0;
        
       
        
        if (int_done) begin
            if(ready_ex[0]) begin
            int_start <= 1'b1;
            int_op1 = src1_val_ex[0];
            int_op2 = src2_val_ex[0];
            int_alu_op = alu_op_ex[0];
            int_dest_tag = dest_tag_ex[0];
            
            //clear_entry[0]<=1'b1;
        end else if (ready_ex[1]) begin
            int_start = 1'b1;
            int_op1 = src1_val_ex[1];
            int_op2 = src2_val_ex[1];
            int_alu_op = alu_op_ex[1];
            int_dest_tag = dest_tag_ex[1];
           // clear_entry[1]<=1'b1;
        end else if (ready_ex[2]) begin
            int_start = 1'b1;
            int_op1 = src1_val_ex[2];
            int_op2 = src2_val_ex[2];
            int_alu_op = alu_op_ex[2];
            int_dest_tag = dest_tag_ex[2];
            //clear_entry[2]<=1'b1;
        end else int_start<= 1'b0; end
        if (branch_done) begin
            if(ready_ex[3]) begin
            branch_start = 1'b1;
            branch_op1 = src1_val_ex[3];
            branch_op2 = src2_val_ex[3];
            branch_alu_op = alu_op_ex[3];
            branch_dest_tag = dest_tag_ex[3];
            end else branch_start<= 1'b0;
            //clear_entry[3]<=1'b1;
        end 
        if (ready_ex[4]) begin
            ls_start = 1'b1;
            ls_op1 = src1_val_ex[4];
            ls_op2 = src2_val_ex[4];
            ls_alu_op = alu_op_ex[4];
            ls_dest_tag = dest_tag_ex[4];
            //clear_entry[4]<=1'b1;
        end
        if (mul_done) begin
            if(ready_ex[5]) begin
          
            mul_start = 1'b1;
            mul_op1 = src1_val_ex[5];
            mul_op2 = src2_val_ex[5];
            mul_alu_op = alu_op_ex[5];
            mul_dest_tag = dest_tag_ex[5];
            end else begin mul_start<=1'b0; end
            //clear_entry[5]<=1'b1;
        end
        if (div_done) begin
            if(ready_ex[6]) begin
            div_start = 1'b1;
            div_op1 = src1_val_ex[6];
            div_op2 = src2_val_ex[6];
            div_alu_op = alu_op_ex[6];
            div_dest_tag = dest_tag_ex[6];
            end else div_start<=1'b0;
            //clear_entry[6]<=1'b1;
        end
            
        
    end       
       
end

          

    
    
    
    
    // Instantiate ALUs using pre-assigned RS indexes
    INT_ALU int_alu (
        .clk(clk),
        .reset(reset),
        .start(int_start),
        .op1(int_op1),
        .op2(int_op2),
        .opcode(int_alu_op),
        .result(int_result),
        .done(int_done),
        .devalidate(int_validate),
        .valid(int_valid)
    );


    BRANCH_ALU branch_alu (
        
        .start(branch_start),
        .op1(branch_op1),
        .op2(branch_op2),
        .taken(branch_result),
        .done(branch_done)
        
    );

    LOADSTORE_ALU ls_alu (
        
    );

    MUL_ALU mul_alu (
        .clk(clk),
        .reset(reset),
        .opcode(mul_alu_op),
        .start(mul_start),
        .op1(mul_op1),
        .op2(mul_op2),
        .result(mul_result),
        .done(mul_done),
        .devalidate(mul_validate),
        .valid(mul_valid)
    );

    DIV_ALU div_alu (
        .clk(clk),
        .reset(reset),
        .start(mul_start),
        .opcode(mul_alu_op),
        .op1(mul_op1),
        .op2(mul_op2),
        .result(div_result),
        .done(div_done)
        
    );

    always @(*) begin
        
            
            if (int_valid) begin
                result <= int_result;
                result_tag <= int_dest_tag;
                valid_out <= 1'b1;
                int_validate<=1'b1;
            end else if (branch_valid) begin
                result <= branch_result;
                result_tag <= dest_tag_ex[3];
                valid_out <= 1'b1;
                branch_validate <=1'b1;
            end else if (loadstore_valid) begin
                result <= loadstore_result;
                result_tag <= dest_tag_ex[4];
                valid_out <= 1'b1;
                loadstore_validate <=1'b1;
            end else if (mul_valid) begin
                result <= mul_result;
                result_tag <= dest_tag_ex[5];
                valid_out <= 1'b1;
                mul_validate <=1'b1;
            end else if (div_valid) begin
                result <= div_result;
                result_tag <= dest_tag_ex[6];
                valid_out <= 1'b1;
                div_validate<=1'b1;
            end else begin
                result <= 32'd0;
                valid_out <= 1'b0;
                result_tag <= 5'b0;
                int_validate<=0;
                mul_validate<=0;
                div_validate<=0;
                branch_validate<=0;
                loadstore_validate<=0;
            end
       
    end

endmodule
