`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/25/2025 10:32:55 PM
// Design Name: 
// Module Name: RAS
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module RAS #(parameter DEPTH = 8) (
    input  wire        clk,
    input  wire        reset,

    // Push interface (for `jal`)
    input  wire        push_en,
    input  wire [31:0] push_addr,

    // Pop interface (for `jalr`)
    input  wire        pop_en,

    // Output top of stack (predicted return address)
    output reg  [31:0] ras_top
);

    reg [31:0] stack [0:DEPTH-1];
    reg [$clog2(DEPTH):0] sp; // Stack pointer (can go one past top for full detection)

    // Stack pointer and top value management
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            sp <= 0;
            ras_top <= 32'b0;
        end else begin
            if (push_en) begin
                stack[sp] <= push_addr;
                sp <= sp + 1;
            end else if (pop_en && sp > 0) begin
                sp <= sp - 1;
            end
        end
    end

    // Read top of stack
    always @(*) begin
        if (sp > 0)
            ras_top = stack[sp - 1];
        else
            ras_top = 32'b0;
    end

endmodule

