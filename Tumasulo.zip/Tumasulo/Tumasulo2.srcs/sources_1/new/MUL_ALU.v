`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2025 02:38:32 PM
// Design Name: 
// Module Name: MUL_ALU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module MUL_ALU (
    input        clk,
    input        reset,
    input devalidate,
    input  [3:0] opcode,
    input  [31:0] op1,
    input  [31:0] op2,
    input        start,
    output reg [31:0] result,
    output reg       done,
    output reg valid
);
    reg [1:0] cycle;

    always @(posedge clk ) begin
        if (reset) begin
            done  <= 1'b1;
            cycle <= 0;
            valid <= 0;
        end else begin
        
            if(devalidate) valid<=0;
                
           else if (start && cycle == 0) begin
                cycle <= 1;
                done  <= 0;
            end else if (cycle == 1) begin
                cycle <= 2;
            end else if (cycle == 2) begin
                cycle <= 0;
                done  <= 1;
                valid <=1;
                case (opcode)
                    4'b1000: result <= op1*op2; // MUL
                    default: result <= 0;
                endcase
            end 
        end
    end
endmodule
