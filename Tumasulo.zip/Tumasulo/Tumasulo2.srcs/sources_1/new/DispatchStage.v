`timescale 1ns / 1ps
module DispatchStage (
    input wire clk,
    input wire reset,
    input wire is_mispredicted,

    // Instruction metadata
    input wire [4:0] src1_tag_Dis,
    input wire [4:0] src2_tag_Dis,
    input wire src1_valid_Dis,
    input wire src2_valid_Dis,
    input wire [31:0] src1_value_Dis,
    input wire [31:0] src2_value_Dis,
    input wire [4:0] dest_tag_Dis,
    input wire [6:0] opcode_Dis,
    input wire [6:0] funct7_Dis,
    input wire [2:0] funct3_Dis,
    input wire [6:0] clear_entry,
    
    input wire [4:0] broadcast_tag,
    input wire [31:0] broadcast_value,
    input wire broadcast_en,
    
    input wire [31:0]commit_broadcast_value,
    input wire [4:0] commit_broadcast_tag,
    input wire commit_broadcast_valid,

    // Outputs to RS
    output wire [223:0] src1_val_ex_flat, // 7 x 32
    output wire [223:0] src2_val_ex_flat,
    output wire [6:0] ready_ex_flat,
    output wire [34:0] dest_tag_ex_flat,
    output wire [27:0] alu_opcode_ex_flat,
    output reg RS_full_stall
    // One-hot signal indicating RS written to
);

    // Internal wires
    wire [6:0] busy_ex;
    wire [4:0] dest_tag_ex[6:0];
    wire [31:0] src1_val_ex[6:0];
    wire [31:0] src2_val_ex[6:0];
    wire [6:0] ready_ex;
    wire [3:0] alu_opcode_ex[6:0];
    reg [6:0] issue_en ;
    wire [3:0] alu_opcode;
    
    
    ALUDecoder AD(
      .funct7(funct7_Dis),
      .funct3(funct3_Dis),
      .opcode(opcode_Dis),
      .alu_opcode(alu_opcode)
      );

    // Reservation stations: INT(3), BR(1), LS(1), MUL(1), DIV(1)
    genvar i;
    generate
        for (i = 0; i < 7; i = i + 1) begin : ALL_RS
            ReservationStation rs_inst (
                .clk(clk),
                .reset(reset),
                .is_mispredicted(is_mispredicted),
                .write_en(issue_en[i]),
                .clear_entry(clear_entry[i]),
                .src1_tag(src1_tag_Dis),
                .src2_tag(src2_tag_Dis),
                .src1_val(src1_value_Dis),
                .src2_val(src2_value_Dis),
                .src1_valid(src1_valid_Dis),
                .src2_valid(src2_valid_Dis),
                .dest_tag(dest_tag_Dis),
                .alu_opcode(alu_opcode),
                .broadcast_tag(broadcast_tag),        // No broadcast in this stage
                .broadcast_value(broadcast_value),
                .broadcast_en(broadcast_en),
                
                .commit_broadcast_value(commit_broadcast_value),
                .commit_broadcast_valid(commit_broadcast_valid),
                .commit_broadcast_tag(commit_broadcast_tag),
        
        
                .busy_RS(busy_ex[i]),
                .src1_val_RS(src1_val_ex[i]),
                .src2_val_RS(src2_val_ex[i]),
                .dest_tag_RS(dest_tag_ex[i]),
                .alu_opcode_RS(alu_opcode_ex[i]),
                .ready_RS(ready_ex[i])
            );
        end
    endgenerate

    // Flatten outputs
    genvar j;
    generate
        for (j = 0; j < 7; j = j + 1) begin : FLATTEN
            assign src1_val_ex_flat[j*32 +: 32] = src1_val_ex[j];
            assign src2_val_ex_flat[j*32 +: 32] = src2_val_ex[j];
            assign ready_ex_flat[j] = ready_ex[j];
            assign dest_tag_ex_flat[j*5 +: 5]=dest_tag_ex[j];
            assign alu_opcode_ex_flat[j*4 +:4]=alu_opcode_ex[j];
        end
    endgenerate

    // Opcode types (example encoding):
    // 7'b0110011: INT
    // 7'b1100011: BRANCH
    // 7'b0000011/0100011: LOAD/STORE
    // 7'b0111011: MUL
    // 7'b0111111: DIV

always @(*) begin
    issue_en = 7'b0;
    RS_full_stall =1'b0;
    case (opcode_Dis)
        7'b0110011: begin // R-type: INT, MUL, DIV
            if (funct7_Dis == 7'b0000001) begin
                case (funct3_Dis)
                    3'b000: if (!busy_ex[5]) issue_en[5] = 1'b1; else RS_full_stall = 1'b1;// MUL
                    3'b100: if (!busy_ex[6]) issue_en[6] = 1'b1; else RS_full_stall = 1'b1;// DIV
                    default: ; // other M-extension ops
                endcase
            end else begin
                if (!busy_ex[0]) issue_en[0] = 1'b1; // INT0
                else if (!busy_ex[1]) issue_en[1] = 1'b1; // INT1
                else if (!busy_ex[2]) issue_en[2] = 1'b1; // INT2
                else RS_full_stall = 1'b1;
            end
        end

        7'b0010011: begin // I-type: ADDI, SLTI, ANDI, ORI, etc.
            if (!busy_ex[0]) issue_en[0] = 1'b1; // INT0
            else if (!busy_ex[1]) issue_en[1] = 1'b1; // INT1
            else if (!busy_ex[2]) issue_en[2] = 1'b1; // INT2
            else RS_full_stall = 1'b1;
        end

        7'b1100011: begin // BRANCH
            if (!busy_ex[3]) issue_en[3] = 1'b1;
            else RS_full_stall = 1'b1;
        end

        7'b0000011, 7'b0100011: begin // LOAD/STORE
            if (!busy_ex[4]) issue_en[4] = 1'b1;
            else RS_full_stall = 1'b1;
        end

        default: ; // No issue
    endcase
end


endmodule
