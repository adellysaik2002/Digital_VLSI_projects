`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/25/2025 09:08:42 PM
// Design Name: 
// Module Name: BTB
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

// Enhanced BTB Module with Return Instruction Support (RAS flag)
module BTB #(parameter BTB_ENTRIES = 1024) (
    input wire clk,
    input wire reset,

    // Query interface
    input wire [31:0] pc_query,         // Current PC to query
    output reg        hit,              // Whether target is valid
    output reg [31:0] predicted_target, // Predicted target PC
    output reg        is_return,        // Mark if instruction is a return (use RAS)
    output reg        is_jal,
    // Update interface
    input wire update_en,
    input wire [31:0] pc_update,        // Branch PC (to index)
    input wire [31:0] target_update,    // Actual target to store
    input wire        return_update,
    input wire        jal_update     // 1 if this instruction is a return (jalr/jr)
);

    // BTB Entry: {valid, tag, target, return_flag}
    reg        valid       [0:BTB_ENTRIES-1];
    reg [21:0] tag         [0:BTB_ENTRIES-1]; // upper 22 bits of PC as tag
    reg [31:0] target_pc   [0:BTB_ENTRIES-1];
    reg        return_flag [0:BTB_ENTRIES-1];
    reg        jal_flag [0:BTB_ENTRIES-1];

    wire [9:0]  index   = pc_query[11:2];   // 1024 entries → use 10 bits
    wire [21:0] pc_tag  = pc_query[31:10];

    always @(*) begin
        if (valid[index] && tag[index] == pc_tag) begin
            hit              = 1;
            predicted_target = target_pc[index];
            is_return        = return_flag[index];
            is_jal           = jal_flag[index];
        end else begin
            hit              = 0;
            predicted_target = 32'b0;
            is_return        = 1'b0;
            is_jal           = 1'b0;
        end
    end
    integer i;
    always @(posedge clk) begin
        if (reset) begin
            
            for (i = 0; i < BTB_ENTRIES; i = i + 1) begin
                valid[i]       <= 0;
                tag[i]         <= 0;
                target_pc[i]   <= 0;
                return_flag[i] <= 0;
                jal_flag[i]    <= 0;
            end
        end else if (update_en) begin
            valid[pc_update[11:2]]       <= 1;
            tag[pc_update[11:2]]         <= pc_update[31:10];
            target_pc[pc_update[11:2]]   <= target_update;
            return_flag[pc_update[11:2]] <= return_update;
            jal_flag[pc_update[11:2]]    <= jal_update;
        end
    end

endmodule


