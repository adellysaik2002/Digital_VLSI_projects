module ReservationStation (
    input wire clk,
    input wire reset,
    input wire is_mispredicted,
    input wire write_en,
    input wire clear_entry, // <--- new signal
    input wire [4:0] src1_tag,
    input wire [4:0] src2_tag,
    input wire [31:0] src1_val,
    input wire [31:0] src2_val,
    input wire src1_valid,
    input wire src2_valid,
    input wire [4:0] dest_tag,
    input wire [3:0] alu_opcode,

    input wire [4:0] broadcast_tag,
    input wire [31:0] broadcast_value,
    input wire broadcast_en,
    
    input wire [31:0]commit_broadcast_value,
    input wire [4:0] commit_broadcast_tag,
    input wire commit_broadcast_valid,

    output reg busy_RS,
    output wire [31:0] src1_val_RS,
    output wire [31:0] src2_val_RS,
    output wire [4:0] dest_tag_RS ,
    output reg [3:0] alu_opcode_RS,
    output  ready_RS
);


    

    reg [4:0] reg_src1_tag, reg_src2_tag;
    
    reg reg_src1_valid, reg_src2_valid;
    
    reg [31:0] reg_src1_val, reg_src2_val;
    
    reg [4:0] reg_dest_tag;
    
    wire ready;
    assign ready = busy_RS && reg_src1_valid && reg_src2_valid;
    assign ready_RS = ready;
    
    assign src1_val_RS=reg_src1_val;
    assign src2_val_RS=reg_src2_val;
    assign dest_tag_RS=reg_dest_tag;

    always @(posedge clk) begin
        
        if (reset || is_mispredicted) begin
            busy_RS <= 1'b0;
            reg_src1_tag <= 5'b0;
            reg_src2_tag <= 5'b0;
            reg_dest_tag <= 5'b0;
            reg_src1_valid <= 1'b0;
            reg_src2_valid <= 1'b0;
            reg_src1_val <= 32'b0;
            reg_src2_val <= 32'b0;
            alu_opcode_RS <= 4'd0;

        end else begin
            if (clear_entry) begin
                // Clear the RS entry after dispatch
                busy_RS <= 1'b0;
                reg_src1_tag <= 5'b0;
                reg_src2_tag <= 5'b0;
                reg_dest_tag <= 5'b0;
                reg_src1_valid <= 1'b0;
                reg_src2_valid <= 1'b0;
                reg_src1_val <= 32'b0;
                reg_src2_val <= 32'b0;
                alu_opcode_RS <= 4'd0;
            end else if (write_en) begin
                busy_RS <= 1'b1;
                reg_src1_tag <= src1_tag;
                reg_src2_tag <= src2_tag;
                reg_dest_tag <= dest_tag;
                reg_src1_valid <= src1_valid;
                reg_src2_valid <= src2_valid;
                reg_src1_val <= src1_val;
                reg_src2_val<= src2_val;
                alu_opcode_RS <= alu_opcode;
                
            end

            // Broadcast logic
            if (broadcast_en) begin
                if (!reg_src1_valid && reg_src1_tag == broadcast_tag) begin
                    reg_src1_valid <= 1'b1;
                    reg_src1_val <= broadcast_value;
                end
                if (!reg_src2_valid && reg_src2_tag == broadcast_tag) begin
                    reg_src2_valid <= 1'b1;
                    reg_src2_val <= broadcast_value;
                end
            end
            
            if (commit_broadcast_valid) begin
                if (!reg_src1_valid && reg_src1_tag == commit_broadcast_tag) begin
                    reg_src1_valid <= 1'b1;
                    reg_src1_val <= commit_broadcast_value;
                end
                if (!reg_src2_valid && reg_src2_tag == commit_broadcast_tag) begin
                    reg_src2_valid <= 1'b1;
                    reg_src2_val <= commit_broadcast_value;
                end
            end
        end
    end

endmodule
