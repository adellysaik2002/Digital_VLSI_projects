`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2025 04:28:54 PM
// Design Name: 
// Module Name: RISCV_Tumasulo_Top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module RISCV_Tumasulo_Top (
    input wire clk,
    input wire reset
);

    // Decode signals
    wire [31:0] PC_D;
    wire [31:0] PC_pred_D;
    wire predict_taken_D;
    wire [31:0] Instruction_D;
    
    //Dispatch signals
     wire [6:0] opcode_Dis;
     wire [2:0] funct3_Dis;
     wire [6:0] funct7_Dis;
     wire [4:0] dest_tag_Dis;
     wire [4:0] src1_tag_Dis;
     wire [4:0] src2_tag_Dis;
     wire [31:0] src1_value_Dis;
     wire [31:0] src2_value_Dis;
     wire src1_valid_Dis;
     wire src2_valid_Dis;
     wire [6:0] clear_entry;
     wire RS_full_stall;
    
    
     wire [223:0] src1_val_ex_flat; // 7 x 32
     wire [223:0] src2_val_ex_flat;
     wire [6:0] ready_ex_flat;
     wire [34:0] dest_tag_ex_flat;
     wire [27:0] alu_op_ex_flat;
     wire [31:0] result;
     wire result_taken;
     wire [4:0] result_tag;
     wire valid_out;
     wire [31:0] target_address;
     wire [31:0]commit_broadcast_value;
     wire [4:0] commit_broadcast_tag;
     wire commit_broadcast_valid;
     

    wire flush = 0;
    wire jump = 0;
    
    wire        predictor_update_en;
    wire [31:0] predictor_pc_update;
    wire        predictor_actual_taken;
    
    wire        btb_update_en;
    wire [31:0] btb_pc_update;
    wire [31:0] btb_target_update;
    wire        btb_is_return_update;

    // === RAS Update Interface ===
    wire        ras_push_en;
    wire [31:0] ras_push_addr;
    wire        ras_pop_en;
    
    
    wire is_mispredicted;
    wire commit_is_branch;
    wire commit_is_jal;
    wire [31:0] correct_address;
    wire commit_actual_taken;
    wire [31:0] commit_branch_pc;

    // Instruction Fetch Stage
InstructionFetch IF (
    .clk(clk),
    .reset(reset),
    .flush(is_mispredicted),
    .RS_full_stall(RS_full_stall),
    .target_address(correct_address),

    // Branch Predictor Update Interface
    .predictor_update_en(commit_is_branch),
    .predictor_pc_update(commit_branch_pc),
    .predictor_actual_taken(commit_actual_taken),

    // BTB Update Interface
    .btb_update_en(commit_is_branch || commit_is_jal),
    .btb_pc_update(commit_branch_pc),
    .btb_target_update(correct_address),
    .btb_is_jal_update(commit_is_jal),
    .btb_is_return_update(btb_is_return_update),

    // RAS Update Interface
    .ras_push_en(ras_push_en),
    .ras_push_addr(ras_push_addr),
    .ras_pop_en(ras_pop_en),

    // Outputs
    .PC_D(PC_D),
    .Instruction_D(Instruction_D),
    .PC_pred_D(PC_pred_D),
    .predict_taken_D(predict_taken_D)
);

    
    
    DecodeStage DE (
        .clk(clk),
        .reset(reset),
        .Instruction_D(Instruction_D),
        .PC_D(PC_D),
        .PC_pred_D(PC_pred_D),
        .predict_taken_D(predict_taken_D),
        
        .is_mispredicted(is_mispredicted),
        .commit_actual_taken(commit_actual_taken),
        .correct_address(correct_address),
        .commit_is_branch(commit_is_branch),
        .commit_is_jal(commit_is_jal),
        .commit_branch_pc(commit_branch_pc),
        
        .opcode_Dis(opcode_Dis),
        .funct3_Dis(funct3_Dis),
        .funct7_Dis(funct7_Dis),
        .dest_tag_Dis(dest_tag_Dis),
        .src1_tag_Dis(src1_tag_Dis),
        .src2_tag_Dis(src2_tag_Dis),
        .src1_value_Dis(src1_value_Dis),
        .src2_value_Dis(src2_value_Dis),
        .src1_valid_Dis(src1_valid_Dis),
        .src2_valid_Dis(src2_valid_Dis),
        .broadcast_taken(result_taken),
        .broadcast_tag(result_tag),
        .broadcast_en(valid_out),
        .broadcast_value(result),
        .broadcast_is_branch(result_is_branch),
        .RS_full_stall(RS_full_stall),
        
        .commit_broadcast_value(commit_broadcast_value),
        .commit_broadcast_valid(commit_broadcast_valid),
        .commit_broadcast_tag(commit_broadcast_tag)
        
    );
    
    
    DispatchStage DIS(
        .clk(clk),
        .reset(reset),
        .is_mispredicted(is_mispredicted),
        .opcode_Dis(opcode_Dis),
        .funct7_Dis(funct7_Dis),
        .funct3_Dis(funct3_Dis),
        .clear_entry(clear_entry),
        .RS_full_stall(RS_full_stall),
        .dest_tag_Dis(dest_tag_Dis),
        .src1_tag_Dis(src1_tag_Dis),
        .src2_tag_Dis(src2_tag_Dis),
        .src1_value_Dis(src1_value_Dis),
        .src2_value_Dis(src2_value_Dis),
        .src1_valid_Dis(src1_valid_Dis),
        .src2_valid_Dis(src2_valid_Dis),
        .src1_val_ex_flat(src1_val_ex_flat),
        .src2_val_ex_flat(src2_val_ex_flat),
        .ready_ex_flat(ready_ex_flat),
        .alu_opcode_ex_flat(alu_op_ex_flat),
        .dest_tag_ex_flat(dest_tag_ex_flat),
        .broadcast_tag(result_tag),
        .broadcast_en(valid_out),
        .broadcast_value(result),
        
        .commit_broadcast_value(commit_broadcast_value),
        .commit_broadcast_valid(commit_broadcast_valid),
        .commit_broadcast_tag(commit_broadcast_tag)
        );
        
     ExecutionStage2 EX(
        .clk(clk),
        .reset(reset),
        .is_mispredicted(is_mispredicted),
        .src1_val_ex_flat(src1_val_ex_flat),
        .src2_val_ex_flat(src2_val_ex_flat),
        .ready_ex_flat(ready_ex_flat),
        .dest_tag_ex_flat(dest_tag_ex_flat),
        .alu_op_ex_flat(alu_op_ex_flat),
        .result(result),
        .result_taken(result_taken),
        .result_is_branch(result_is_branch),
        .result_tag(result_tag),
        .valid_out(valid_out),
        .clear_entry(clear_entry)
        );
        
        
        
        



endmodule
