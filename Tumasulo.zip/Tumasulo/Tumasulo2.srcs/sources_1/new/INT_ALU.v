`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/19/2025 01:51:59 PM
// Design Name: 
// Module Name: INT_ALU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module INT_ALU(
     input clk,
     input reset,
     input start,
     input [31:0] op1,
     input [31:0] op2,
     input [3:0] opcode,
     input devalidate,
     output reg done,
     output reg[31:0] result,
     output reg valid
     

    );
    
    wire flag1;
    assign flag1=( op1==32'd2 && op2==32'd3)?1:0;
    
    reg [31:0] unlatched_result;
    
    
    always@(*) begin
            case (opcode)
                4'b0000: unlatched_result =op1+op2; // ADD
                4'b0001: unlatched_result = op1 - op2; // SUB
                4'b0010: unlatched_result = op1 & op2; // AND
                4'b0011: unlatched_result = op1 | op2; // OR
                4'b0100: unlatched_result = op1 ^ op2; // XOR
                4'b0101: unlatched_result = op1 << op2[4:0]; // SLL
                4'b0110: unlatched_result = op1 >> op2[4:0]; // SRL
                4'b0111: unlatched_result = $signed(op1) >>> op2[4:0]; // SRA
                default: unlatched_result = 32'd0;
            endcase
            
        end
    
    
     always @(posedge clk) begin
        if (reset) begin
            done  <= 1'b1;
            valid <=1'b0;
            result<=32'd0;
        end else begin
       
       // if(devalidate) valid<=0;
         if (start) begin
            result<=unlatched_result;
            done = 1;
            valid=1;
        end
        else result =32'd0;
    end
    end
endmodule

