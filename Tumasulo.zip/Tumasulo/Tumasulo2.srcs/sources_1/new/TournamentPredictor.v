`timescale 1ns / 1ps

module TournamentPredictor #(parameter HISTORY_BITS = 10, TABLE_SIZE = 1024) (
    input wire clk,
    input wire reset,

    // Query from fetch stage
    input wire [31:0] pc_query,
    output reg        predict_taken,

    // Update from commit stage
    input wire        update_en,
    input wire [31:0] pc_update,
    input wire        actual_taken
);

    // === Internal signals ===
    wire pshare_pred, gshare_pred;
    wire [HISTORY_BITS-1:0] pshare_history_out;
    wire [HISTORY_BITS-1:0] gshare_history_out;

    reg [1:0] selector_table [0:TABLE_SIZE-1];
    wire [1:0] selector = selector_table[pc_query[11:2]];

    // === Instantiate PShare Predictor ===
    PSharePredictor #(HISTORY_BITS, TABLE_SIZE) pshare (
        .clk(clk),
        .reset(reset),
        .pc_query(pc_query),
        .update_en(update_en),
        .pc_update(pc_update),
        .actual_taken(actual_taken),
        .prediction(pshare_pred),
        .local_history_out(pshare_history_out)
    );

    // === Instantiate GShare Predictor ===
    GSharePredictor #(HISTORY_BITS, TABLE_SIZE) gshare (
        .clk(clk),
        .reset(reset),
        .pc_query(pc_query),
        .update_en(update_en),
        .pc_update(pc_update),
        .actual_taken(actual_taken),
        .global_history(gshare_history_out),
        .prediction(gshare_pred),
        .global_history_out(gshare_history_out)
    );

    // === Prediction Selection ===
    always @(*) begin
        predict_taken = (selector >= 2) ? pshare_pred : gshare_pred;
    end

    // === Selector Table Update ===
    integer i;
    always @(posedge clk) begin
        if (reset) begin
            for (i = 0; i < TABLE_SIZE; i = i + 1)
                selector_table[i] <= 2'b10; // Prefer GShare
        end else if (update_en) begin
            if (gshare_pred != pshare_pred) begin
                if (pshare_pred == actual_taken && selector_table[pc_update[11:2]] != 2'b11)
                    selector_table[pc_update[11:2]] <= selector_table[pc_update[11:2]] + 1;
                else if (gshare_pred == actual_taken && selector_table[pc_update[11:2]] != 2'b00)
                    selector_table[pc_update[11:2]] <= selector_table[pc_update[11:2]] - 1;
            end
        end
    end

endmodule
