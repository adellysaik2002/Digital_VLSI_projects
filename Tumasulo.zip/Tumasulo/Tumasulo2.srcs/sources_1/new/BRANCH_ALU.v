`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2025 02:40:40 PM
// Design Name: 
// Module Name: BRANCH_ALU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module BRANCH_ALU (
    input  [3:0]  opcode,
    input  [31:0] op1,
    input  [31:0] op2,
    input         start,
    output reg    taken,
    output reg    done
);
    always @(*) begin
        taken = 0;
        done = 0;
        if (start) begin
            case (opcode)
                4'b1011: taken = (op1 == op2);  // BEQ
                4'b1100: taken = (op1 != op2);  // BNE
                4'b1101: taken = ($signed(op1) < $signed(op2)); // BLT
                4'b1110: taken = ($signed(op1) >= $signed(op2)); // BGE
                default: taken = 0;
            endcase
            done = 1;
        end
    end
endmodule
