`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2025 10:40:03 PM
// Design Name: 
// Module Name: ReorderBuffer
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module ReorderBuffer #(parameter DEPTH = 16) (
    input wire clk,
    input wire reset,

    // Allocation
    input wire alloc_en,
    input wire [4:0] rd_in,
    output reg [4:0] alloc_index,
    output wire full,

    // Write-back
    input wire wb_en,
    input wire [4:0] wb_index,
    input wire [31:0] wb_value,

    // Commit
    input wire commit_en,
    output reg [4:0] commit_rd,
    output reg [31:0] commit_val,
    output reg commit_valid,
    output reg [4:0] commit_rob_idx,

    output reg [4:0] head,
    output reg [4:0] tail
);

    // Replace struct with separate arrays for each field
    reg valid      [0:DEPTH-1];
    reg ready      [0:DEPTH-1];
    reg [4:0] rd   [0:DEPTH-1];
    reg [31:0] value [0:DEPTH-1];

    assign full = ((tail) % (DEPTH-1)+1) == head;

    integer i;
    always @(posedge clk) begin
        if (reset) begin
            head <= 1;
            tail <= 1;
            alloc_index <= 5'd0;
            commit_rd <=5'd0;
            commit_val <= 32'd0;
            commit_valid <= 1'b0;
            commit_rob_idx <= 5'd0;

            for (i = 0; i < DEPTH; i = i + 1) begin
                valid[i] <= 0;
                ready[i] <= 0;
                rd[i] <= 5'd0;
                value[i] <=32'd0;
            end
        end else begin
            // Allocation
            if (alloc_en && !full) begin
                valid[tail]  <= 1;
                ready[tail]  <= 0;
                rd[tail]     <= rd_in;
                alloc_index  <= tail;
                tail         <= (tail) % (DEPTH-1)+1;
            end

            // Write-back
            if (wb_en) begin
                value[wb_index] <= wb_value;
                ready[wb_index] <= 1;
            end

            // Commit
            commit_valid <= 0;
            if (commit_en && valid[head] && ready[head]) begin
                commit_rd    <= rd[head];
                commit_val   <= value[head];
                commit_valid <= 1;
                commit_rob_idx <= head;
                valid[head]  <= 0;
                head         <= (head) % (DEPTH-1)+1;
            end
        end
    end

endmodule
