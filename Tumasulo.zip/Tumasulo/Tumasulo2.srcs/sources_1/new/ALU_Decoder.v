`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/19/2025 11:11:36 PM
// Design Name: 
// Module Name: ALU_Decoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module ALUDecoder (
    input  [6:0] funct7,
    input  [2:0] funct3,
    input  [6:0] opcode,
    output reg [3:0] alu_opcode
);

    wire [9:0] funct_combined = {funct7, funct3};

    always @(*) begin
        case (opcode)
            7'b0110011: begin // R-type and MUL/DIV
                case (funct_combined)
                    10'b0000000000: alu_opcode = 4'b0000; // ADD
                    10'b0100000000: alu_opcode = 4'b0001; // SUB
                    10'b0000000111: alu_opcode = 4'b0010; // AND
                    10'b0000000110: alu_opcode = 4'b0011; // OR
                    10'b0000000100: alu_opcode = 4'b0100; // XOR
                    10'b0000000001: alu_opcode = 4'b0101; // SLL
                    10'b0000000101: alu_opcode = 4'b0110; // SRL
                    10'b0100000101: alu_opcode = 4'b0111; // SRA
                    10'b0000001000: alu_opcode = 4'b1000; // MUL
                    10'b0000001001: alu_opcode = 4'b1001; // MULH
                    10'b0000001010: alu_opcode = 4'b1010; // MULHSU
                    10'b0000001011: alu_opcode = 4'b1011; // MULHU
                    10'b0000001100: alu_opcode = 4'b1100; // DIV
                    10'b0000001101: alu_opcode = 4'b1101; // DIVU
                    10'b0000001110: alu_opcode = 4'b1110; // REM
                    10'b0000001111: alu_opcode = 4'b1111; // REMU
                    default: alu_opcode = 4'b0000; // Invalid
                endcase
            end
            7'b0010011: begin // I-type
                case (funct3)
                    3'b000: alu_opcode = 4'b0000; // ADDI
                    3'b111: alu_opcode = 4'b0010; // ANDI
                    3'b110: alu_opcode = 4'b0011; // ORI
                    3'b100: alu_opcode = 4'b0100; // XORI
                    3'b001: alu_opcode = 4'b0101; // SLLI
                    3'b101: begin
                        case (funct7)
                            7'b0000000: alu_opcode = 4'b0110; // SRLI
                            7'b0100000: alu_opcode = 4'b0111; // SRAI
                            default:    alu_opcode = 4'b0000;
                        endcase
                    end
                    default: alu_opcode = 4'b0000;
                endcase
            end
            7'b1100011: begin // Branches
                case (funct3)
                    3'b000: alu_opcode = 4'b1000; // BEQ
                    3'b001: alu_opcode = 4'b1001; // BNE
                    3'b100: alu_opcode = 4'b1010; // BLT
                    3'b101: alu_opcode = 4'b1011; // BGE
                    3'b110: alu_opcode = 4'b1100; // BLTU
                    3'b111: alu_opcode = 4'b1101; // BGEU
                    default: alu_opcode = 4'b0000;
                endcase
            end
            7'b0000011: alu_opcode = 4'b0000; // LOADs: treat as ADD
            7'b0100011: alu_opcode = 4'b0000; // STOREs: treat as ADD
            default:    alu_opcode = 4'b0000; // Invalid / NOP
        endcase
    end

endmodule
