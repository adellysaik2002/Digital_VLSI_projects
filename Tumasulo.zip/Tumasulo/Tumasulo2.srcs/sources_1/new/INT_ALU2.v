`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/22/2025 10:04:33 AM
// Design Name: 
// Module Name: INT_ALU2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module INT_ALU2(
   input clk,
   input reset,
   input is_mispredicted,
   input [31:0] int_op1,
   input [31:0] int_op2,
   input [4:0] int_dest_tag,
   input [3:0] int_alu_op,
   input int_ready,
   input int_broadcast,
   output int_clear,
   output reg [31:0] int_result_out,
   output reg [4:0] int_dest_tag_out,
   output reg int_valid_out
   
     );
     
     
     parameter IDLE=0,START=1,DONE=2;
     
     reg [1:0] state,next_state;
     
     
     reg [31:0] op1;
     reg [31:0] op2;
     reg [3:0] alu_op;
     reg [4:0] dest_tag;
     
     
     
     always@(posedge clk)
        if(reset || is_mispredicted) state<=IDLE;
        else state<=next_state;
     
     assign int_clear = ((state == IDLE)&& (int_ready==1))||((state==DONE)&& int_broadcast && int_ready);
     always@(*)
       case(state)
          IDLE:begin
                 next_state<=(int_ready==1)?START:IDLE;
                 
               end
          START: next_state<=DONE;
          DONE:  next_state=(int_broadcast==1)?((int_ready==1)?START:IDLE):DONE;
       endcase
       
       
     always@(posedge clk) begin
         if(reset || is_mispredicted) begin
            op1<=32'd0;
            op2<=32'd0;
            alu_op<=4'd0;
            int_result_out<=32'd0;
            int_dest_tag_out<=5'd0;
            int_valid_out<=1'd0;
         end  
         
         else begin
           if(int_clear==1) begin
             op1<=int_op1;
             op2<=int_op2;
             alu_op<=int_alu_op;
             dest_tag <= int_dest_tag;
           end 
           else if(state==DONE && int_broadcast)begin
            op1<=32'd0;
            op2<=32'd0;
            alu_op<=4'd0;
            int_result_out<=32'd0;
            int_dest_tag_out<=5'd0;
            int_valid_out<=1'd0;
         end  
           
           if(state==START) begin
             case (alu_op)
                4'b0000: int_result_out =op1+op2; // ADD
                4'b0001: int_result_out = op1 - op2; // SUB
                4'b0010: int_result_out = op1 & op2; // AND
                4'b0011: int_result_out = op1 | op2; // OR
                4'b0100: int_result_out = op1 ^ op2; // XOR
                4'b0101: int_result_out = op1 << op2[4:0]; // SLL
                4'b0110: int_result_out = op1 >> op2[4:0]; // SRL
                4'b0111: int_result_out = $signed(op1) >>> op2[4:0]; // SRA
                default: int_result_out = 32'd0;
            endcase
            int_dest_tag_out <= dest_tag;
            int_valid_out <= 1'd1;
            
           end
         end
       end
             
         
     
     
endmodule
